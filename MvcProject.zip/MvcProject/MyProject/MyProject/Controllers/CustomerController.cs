﻿using MyProject.Models;
using Newtonsoft.Json;
using PagedList;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Xml;

namespace MyProject.Controllers
{
    public class CustomerController : Controller
    {
        MyContextDB db = new MyContextDB();
        // GET: Customer
        public ActionResult SearchSortPagingIndex(string SearchString, string CurrentFilter, string SortOrder, int? Page)
        {
            ViewBag.SortNameParam = string.IsNullOrEmpty(SortOrder) ? "name_desc" : " ";
            //Searching
            if (SearchString != null)
            {
                Page = 1;
            }
            else
            {
                SearchString = CurrentFilter;
            }
            ViewBag.CurrentFilter = SearchString;

            var CustomerList = db.Customers.Where(s => s.IsDeleted == false)
                .Select(s => new CustomerViewModel
                {
                    CustomerId = s.CustomerId,
                    CustomeraName = s.CustomeraName,
                    Address = s.Address,
                    Email = s.Email,
                    Type = s.Account.Type
                }).ToList();

            if (!string.IsNullOrEmpty(SearchString))
            {
                CustomerList = CustomerList.Where(s => s.CustomeraName.ToUpper().Contains(SearchString.ToUpper())).ToList();
            }
            //Sorting
            switch (SortOrder)
            {
                case "name_desc":
                    CustomerList = CustomerList.OrderByDescending(s => s.CustomeraName).ToList();
                    break;
                default:
                    CustomerList = CustomerList.OrderBy(s => s.CustomeraName).ToList();
                    break;
            }
            ViewBag.CurrentSort = SortOrder;

            //Paging
            int PageSize = 2;
            int PageNumber = (Page ?? 1);
            return View(CustomerList.ToPagedList(PageNumber, PageSize));
        }
        //Ajax Option
        public PartialViewResult AllBooks()
        {
            System.Threading.Thread.Sleep(2000);
            List<CustomerViewModel> CustomerList = db.Customers.Where(s => s.IsDeleted == false)
                 .Select(s => new CustomerViewModel
                 {
                     CustomerId = s.CustomerId,
                     CustomeraName = s.CustomeraName,
                     Address = s.Address,
                     Email = s.Email,
                     Type = s.Account.Type
                 }).ToList();
            return PartialView("_CustomerList", CustomerList);
        }

        public PartialViewResult AllCustomerAsc()
        {
            System.Threading.Thread.Sleep(2000);

            List<CustomerViewModel> CustomerList = db.Customers.Where(s => s.IsDeleted == false)
                 .Select(s => new CustomerViewModel
                 {
                     CustomerId = s.CustomerId,
                     CustomeraName = s.CustomeraName,
                     Address = s.Address,
                     Email = s.Email,
                     Type = s.Account.Type
                 }).ToList();
            CustomerList = CustomerList.OrderBy(s => s.CustomeraName).ToList();
            return PartialView("_CustomerList", CustomerList);
        }

        public PartialViewResult AllCustomerDsc()
        {
            System.Threading.Thread.Sleep(2000);
            List<CustomerViewModel> CustomerList = db.Customers.Where(s => s.IsDeleted == false)
                 .Select(s => new CustomerViewModel
                 {
                     CustomerId = s.CustomerId,
                     CustomeraName = s.CustomeraName,
                     Address = s.Address,
                     Email = s.Email,
                     Type = s.Account.Type
                 }).ToList();
            CustomerList = CustomerList.OrderByDescending(s => s.CustomeraName).ToList();
            return PartialView("_CustomerList", CustomerList);
        }

        public ActionResult Index()
        {
            List<Account> Clist = db.Accounts.ToList();
            ViewBag.ListOfAccounts = new SelectList(Clist, "AccountId", "Type");
            return View();
        }
        public JsonResult GetCustomerList()
        {
            System.Threading.Thread.Sleep(2000);
            List<CustomerViewModel> Blist = db.Customers.Where(s => s.IsDeleted == false).Select(s => new CustomerViewModel
            {
                CustomerId = s.CustomerId,
                CustomeraName = s.CustomeraName,
                Address = s.Address,
                Email = s.Email,
                Type = s.Account.Type

            }).ToList();
            return Json(Blist, JsonRequestBehavior.AllowGet);

        }
        public PartialViewResult GetDetailCustomerRecord(int CustomerId)
        {
            Customer obj = db.Customers.SingleOrDefault(s => s.IsDeleted == false && s.CustomerId == CustomerId);
            CustomerViewModel viewObj = new CustomerViewModel();
            viewObj.CustomerId = obj.CustomerId;
            viewObj.CustomeraName = obj.CustomeraName;
            viewObj.Address = obj.Address;
            viewObj.Email = obj.Email;
            viewObj.Type = obj.Account.Type;
            return PartialView("_CustomerDetails", viewObj);
        }
        public JsonResult GetCustomerById(int CustomerId)
        {
            Customer model = db.Customers.Where(s => s.CustomerId == CustomerId).SingleOrDefault();
            string value = string.Empty;
            value = JsonConvert.SerializeObject(model, Newtonsoft.Json.Formatting.Indented, new JsonSerializerSettings
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
            });
            return Json(value, JsonRequestBehavior.AllowGet);
        }
        public JsonResult SaveDataInDatabase(CustomerViewModel model)
        {
            var result = false;
            try
            {
                if (model.CustomerId > 0)
                {
                    Customer customer = db.Customers.SingleOrDefault(x => x.IsDeleted == false && x.CustomerId == model.CustomerId);
                    customer.CustomeraName = model.CustomeraName;
                    customer.Address = model.Address;
                    customer.Email = model.Email;
                    customer.AccountId = model.AccountId;
                    db.SaveChanges();
                    result = true;
                }
                else
                {
                    Customer customer = new Customer();
                    customer.CustomeraName = model.CustomeraName;
                    customer.Address = model.Address;
                    customer.Email = model.Email;
                    customer.AccountId = model.AccountId;
                    customer.IsDeleted = false;
                    db.Customers.Add(customer);
                    db.SaveChanges();
                    result = true;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return Json(result, JsonRequestBehavior.AllowGet);

        }
        public JsonResult DeleteCustomerRecord(int CustomerId)
        {
            bool result = false;
            Customer bk = db.Customers.SingleOrDefault(x => x.IsDeleted == false && x.CustomerId == CustomerId);
            if (bk != null)
            {
                bk.IsDeleted = true;
                db.SaveChanges();
                result = true;
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
    }
    
}
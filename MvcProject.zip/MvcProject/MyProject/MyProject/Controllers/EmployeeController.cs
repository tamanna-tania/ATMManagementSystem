﻿using MyProject.Models;
using PagedList;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MyProject.Controllers
{
    public class EmployeeController : Controller
    {
        MyContextDB db = new MyContextDB();
        // GET: Employee
        public ActionResult Index(string SearchString, string CurrentFilter, string SortOrder, int? page)
        {

            List<EmployeeViewModel> memberList = db.Employees.Select(u => new EmployeeViewModel
            {
                EmployeeId = u.EmployeeId,
                EmpName = u.EmpName,
                Email = u.Email,
                DOB = u.DOB,
                ImageName = u.ImageName,
                ImageUrl = u.ImageUrl
            }).ToList();
            ViewBag.SortNameParam = string.IsNullOrEmpty(SortOrder) ? "name_desc" : "";
            if (SearchString != null)
            {
                page = 1;
            }
            else
            {
                SearchString = CurrentFilter;
            }
            ViewBag.CurrentFilter = SearchString;

            var list = memberList;
            if (!string.IsNullOrEmpty(SearchString))
            {
                list = list.Where(u => u.EmpName.ToUpper().
                Contains(SearchString.ToUpper())).ToList();
            }
            switch (SortOrder)
            {
                case "name_desc":
                    list = list.OrderByDescending(u => u.EmpName).ToList();
                    break;
                default:
                    list = list.OrderBy(u => u.EmpName).ToList();
                    break;
            }
            int PageSize = 3;
            int PageNumber = (page ?? 1);

            return View(list.ToPagedList(PageNumber, PageSize));
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(EmployeeViewModel vobj)
        {
            var result = false;
            try
            {
                Employee obj;
                if (vobj.EmployeeId == 0)
                {
                    obj = new Employee();
                    obj.EmpName = vobj.EmpName;
                    obj.Email = vobj.Email;
                    obj.DOB = vobj.DOB;
                    string fileName = Path.GetFileNameWithoutExtension(vobj.ImageFile.FileName);
                    string extension = Path.GetExtension(vobj.ImageFile.FileName);
                    fileName = fileName + DateTime.Now.ToString("yymmssfff") + extension;
                    vobj.ImageUrl = "~/Images/" + fileName;
                    fileName = Path.Combine(Server.MapPath("~/Images/" + fileName));
                    vobj.ImageFile.SaveAs(fileName);
                    obj.ImageName = vobj.ImageName;
                    obj.ImageUrl = vobj.ImageUrl;
                    db.Employees.Add(obj);
                    db.SaveChanges();
                    result = true;
                }
                else
                {
                    obj = db.Employees.SingleOrDefault(u => u.EmployeeId == vobj.EmployeeId);
                    obj.EmpName = vobj.EmpName;
                    obj.Email = vobj.Email;
                    obj.DOB = vobj.DOB;
                    string fileName = Path.GetFileNameWithoutExtension(vobj.ImageFile.FileName);
                    string extension = Path.GetExtension(vobj.ImageFile.FileName);
                    fileName = fileName + DateTime.Now.ToString("yymmssfff") + extension;
                    vobj.ImageUrl = "~/Images/" + fileName;
                    fileName = Path.Combine(Server.MapPath("~/Images/" + fileName));
                    vobj.ImageFile.SaveAs(fileName);
                    obj.ImageName = vobj.ImageName;
                    obj.ImageUrl = vobj.ImageUrl;
                    db.SaveChanges();
                    result = true;

                }
                if (result)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    return View();
                }
            }
            catch (Exception)
            {
                throw;
            }

        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            Employee obj = db.Employees.SingleOrDefault(u => u.EmployeeId == id);
            EmployeeViewModel vobj = new EmployeeViewModel();
            vobj.EmpName = obj.EmpName;
            vobj.Email = obj.Email;
            vobj.DOB = obj.DOB;
            vobj.ImageName = obj.ImageName;
            vobj.ImageUrl = obj.ImageUrl;
            vobj.EmployeeId = obj.EmployeeId;
            return View(vobj);
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {
            Employee obj = db.Employees.SingleOrDefault(u => u.EmployeeId == id);
            EmployeeViewModel vobj = new EmployeeViewModel();
            vobj.EmpName = obj.EmpName;
            vobj.Email = obj.Email;
            vobj.DOB = obj.DOB;
            vobj.ImageName = obj.ImageName;
            vobj.ImageUrl = obj.ImageUrl;
            vobj.EmployeeId = obj.EmployeeId;
            return View(vobj);
        }
        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteConfirm(int id)
        {
            Employee obj = db.Employees.SingleOrDefault(u => u.EmployeeId == id);
            if (obj != null)
            {
                db.Employees.Remove(obj);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View(obj);
            }

        }
        public PartialViewResult Details(int id)
        {
            Employee obj = db.Employees.SingleOrDefault(u => u.EmployeeId == id);
            EmployeeViewModel vobj = new EmployeeViewModel();
            vobj.EmpName = obj.EmpName;
            vobj.Email = obj.Email;
            vobj.DOB = obj.DOB;
            vobj.ImageName = obj.ImageName;
            vobj.ImageUrl = obj.ImageUrl;
            vobj.EmployeeId = obj.EmployeeId;
            ViewBag.Details = "Show";
            return PartialView("_EmployeeDelails", vobj);
        }
    }
}
﻿using MyProject.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MyProject.Controllers
{
    public class TranController : Controller
    {
        // GET: Tran
        MyContextDB db = new MyContextDB();
        public ActionResult Index()
        {
            var data = db.Trans.ToList();
            return View(data);
        }
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(Tran tran)
        {

            //if (ModelState.IsValid)
            //{
            //    if (tran.TranId > 0)
            //    {
            //        db.Entry(tran).State = EntityState.Modified;
            //    }
            //    else
            //    {
            //        db.Trans.Add(tran);
            //    }
            //    db.SaveChanges();
            //}
            //return RedirectToAction("/Index");

            if (ModelState.IsValid)
            {
                db.Trans.Add(tran);
                db.SaveChanges();
            }
            return RedirectToAction("Index");
        }


        public ActionResult Delete(int? id)
        {
            var data = db.Trans.Find(id);
            if (data != null)
            {
                db.Trans.Remove(data);
                db.SaveChanges();
            }
            return RedirectToAction("/");
        }
        public ActionResult Details(int? id)
        {
            var data = db.Trans.Find(id);
            if (data == null)
            {
                Response.Redirect("/Index");
            }
            return View(data);

        }
      

    }
}
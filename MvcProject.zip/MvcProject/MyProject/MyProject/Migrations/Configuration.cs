namespace MyProject.Migrations
{
    using MyProject.Models;
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<MyProject.Models.MyContextDB>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(MyProject.Models.MyContextDB context)
        {
            context.Accounts.AddOrUpdate(x => x.AccountId,
         new Account() { AccountId = 1, Type = "Deposit" },
        new Account() { AccountId = 2, Type = "FDR" },
        new Account() { AccountId = 3, Type = "Fixed" }
         );


            context.Customers.AddOrUpdate(x => x.CustomerId,
        new Customer() { CustomerId = 1, CustomeraName = "Tani", Address = "295/L", Email = "tani@gmail.com", IsDeleted = false, AccountId = 1 },
                new Customer() { CustomerId = 2, CustomeraName = "bin", Address = "29/L", Email = "bin@gmail.com", IsDeleted = false, AccountId = 2 }

        );

            context.Employees.AddOrUpdate(x => x.EmployeeId,
   new Employee() { EmployeeId = 1, EmpName = "Tani", Email = "tani@gmail.com", DOB = System.DateTime.Parse("5/4/2009"), ImageName = "download.jpg", ImageUrl = "~/images/" },
    new Employee() { EmployeeId = 2, EmpName = "Ritu", Email = "ritu@gmail.com", DOB = System.DateTime.Parse("5/4/2010"), ImageName = "download.jpg", ImageUrl = "~/images/" }


   );

            context.Trans.AddOrUpdate(x => x.TranId,
   new Tran() { TranId = 1, Balance = 10000, Withdraw = 1000, },
new Tran() { TranId = 2, Balance = 100000, Withdraw = 2000, }
   );

            context.Users.AddOrUpdate(x => x.UserId,
   new User() { UserId = 1, UserName = "Tani", Password = "123", Role = "Admin" },
 new User() { UserId = 2, UserName = "Faru", Password = "1234", Role = "User" }
   );

        }

        //  This method will be called after migrating to the latest version.

        //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
        //  to avoid creating duplicate seed data.
    
    }
}

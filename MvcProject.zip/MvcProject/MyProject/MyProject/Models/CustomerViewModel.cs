﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyProject.Models
{
    public class CustomerViewModel
    {
        public int CustomerId { get; set; }
        public string CustomeraName { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
        public bool IsDeleted { get; set; }
        public int AccountId { get; set; }
        public string Type { get; set; }
        public virtual Account Account { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyProject.Models
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string EmpName { get; set; }
        public string Email { get; set; }
        public DateTime DOB { get; set; }
        public string ImageName { get; set; }
        public string ImageUrl { get; set; }
        
    }
}
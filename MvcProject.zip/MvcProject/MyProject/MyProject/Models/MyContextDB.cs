﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace MyProject.Models
{
    public class MyContextDB : DbContext
    {

        public MyContextDB() : base("MyContextDB") { }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Account> Accounts { get; set; }
        public DbSet<Tran> Trans { get; set; }
        public DbSet<User> Users { get; set; }
       
    }
}
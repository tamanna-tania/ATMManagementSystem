﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyProject.Models
{
    public class Tran
    {
        public int TranId { get; set; }
        public decimal Balance { get; set; }
        public decimal Withdraw { get; set; }
    }
}